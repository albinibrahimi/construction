
  
<?php $__env->startSection('content'); ?>      
    <div class="row">  
    <h2 class="text-center mt-4 mb-3">Ndrysho madhësinë për banesën: <?php echo e($metrat); ?>m2 në objektin <?php echo e($objekt->name); ?></h2>
    </div>

<form method="post" action="<?php echo e(route('updateapartment', ['m2' => $metrat, 'objektid' => $objekt->id])); ?>">
            <?php echo method_field('PATCH'); ?> 
            <?php echo csrf_field(); ?> 
            <div class="form-group">
                <label>M2:</label>
                <input type="text" name="m2" value="<?php echo e($metrat); ?>" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary mt-2">Ruaj</button>
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\construction\resources\views/admin/editapartment.blade.php ENDPATH**/ ?>