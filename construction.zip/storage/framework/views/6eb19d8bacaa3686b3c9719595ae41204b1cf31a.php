

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center">
    <img src="/images/admin.png" width="200">
</div>
<?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
<table class="table  table-dark text-center align-middle">
  <thead>
    <tr>
      <th scope="col">Objekti: <?php echo e($objekt->name); ?></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
        <a class="btn btn-success" href="<?php echo e(route('createbanesa', $objekt->id)); ?>">Shto banesë</a>
        <a class="btn btn-primary" href="<?php echo e(route('apartments', $objekt->id)); ?>">Listo banesat</a>
        <a href="/" 
                    class="btn btn-danger"
                   onclick="event.preventDefault();
                    document.getElementById(
                      'delete-form').submit();">
                 Fshij Objektin 
                </a>
            </td>
        <form id="delete-form" + action="<?php echo e(route('destroybuilding', ['id' => $objekt->id, 'objektid' => $objekt->id])); ?>"
                  method="post">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            </form>
        
    </td>
    </tr>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\construction\resources\views/admin/editbuilding.blade.php ENDPATH**/ ?>