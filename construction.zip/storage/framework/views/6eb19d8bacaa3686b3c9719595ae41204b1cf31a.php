

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center">
    <img src="/images/admin.png" width="200">
</div>
<table class="table  table-dark text-center align-middle">
  <thead>
    <tr>
      <th scope="col">Objekti: <?php echo e($objekt->name); ?></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
        <a class="btn btn-success" href="<?php echo e(route('createbanesa', $objekt->id)); ?>">Shto banesë</a>
        <a class="btn btn-primary" href="<?php echo e(route('apartments', $objekt->id)); ?>">Listo banesat</a>
        <a class="btn btn-danger" href="<?php echo e(route('createbanesa', $objekt->id)); ?>">Fshij objektin</a>
    </td>
    </tr>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\construction\resources\views/admin/editbuilding.blade.php ENDPATH**/ ?>