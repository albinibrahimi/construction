

<?php $__env->startSection('content'); ?>

<h1 class="text-center mt-4 mb-5"><?php echo e($objekti->name); ?></h1>
<?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <table class="table  table-dark text-center align-middle">
  <thead>
    <tr>
      <th scope="col">Kati</th>
      <th scope="col">M2</th>
      <th scope="col">Statusi</th>
      <?php if(auth()->guard()->check()): ?>
      <th scope="col">Opsioni</th>
        <?php endif; ?>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $banesat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banesa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($banesa->kati); ?></td>
      <td><?php echo e($banesa->m2); ?> m2</td>
      <?php if($banesa->statusi =='0'): ?>
      <td class="bg-success">E lirë</td>
      <?php elseif($banesa->statusi =='2'): ?>
      <td class="bg-warning">E rezervuar</td>
      <?php else: ?>
      <td class="bg-danger">E shitur</td>
      <?php endif; ?>
      <?php if(auth()->guard()->check()): ?>
      <td><a class="btn btn-primary" href="<?php echo e(route('edit', $banesa->id)); ?>">Ndërro statusin</a></td>
        <?php endif; ?>
      
    </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<div class="d-flex justify-content-center">
    <?php echo e($banesat->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\construction\resources\views/banesat.blade.php ENDPATH**/ ?>