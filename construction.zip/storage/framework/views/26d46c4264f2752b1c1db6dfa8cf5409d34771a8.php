

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center">
    <img src="/images/admin.png" width="200">
</div>
<?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
<table class="table  table-dark text-center align-middle">
  <thead>
    <tr><th scope="col" colspan="3">Banesat për objektin: <?php echo e($objekt->name); ?></th></tr>
    <tr>
      <th scope="col">Banesat</th>
      <th scope="col" colspan="2">Opsioni</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $apartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($apartment->m2); ?>m2</td>
      <td>
        <a class="btn btn-success" href="<?php echo e(route('editapartment', ['m2' => $apartment->m2, 'objektid' => $objekt->id])); ?>">Ndrysho madhësinë</a>
        <td>
        <form method="post" action="<?php echo e(route('destroy', ['m2' => $apartment->m2, 'objektid' => $objekt->id])); ?>">
                  <button onclick="return confirm('A jeni i sigurtë se doni të fshini banesën me madhësi <?php echo e($apartment->m2); ?>m2 ?' )" type="submit" class="btn btn-danger">Delete</button>
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            </form>
        
    </td>
    </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\construction\resources\views/admin/apartments.blade.php ENDPATH**/ ?>