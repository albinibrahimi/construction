

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center">
    <img src="/images/admin.png" width="200">
</div>
<table class="table  table-dark text-center align-middle">
  <thead>
    <tr>
      <th scope="col">Objekti</th>
      <th scope="col" colspan="2">Opsioni</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $objekts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objekt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($objekt->name); ?></td>
      <td><a class="btn btn-primary" href="<?php echo e(route('editbuilding', $objekt->id)); ?>">Selekto</a></td>
    </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\construction\resources\views/admin/panel.blade.php ENDPATH**/ ?>