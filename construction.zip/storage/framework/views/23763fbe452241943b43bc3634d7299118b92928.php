
  
<?php $__env->startSection('content'); ?>      
    <div class="row">  
    <h2 class="text-center mt-4 mb-3">Ndrysho statusin për banesën: <?php echo e($banesa->m2); ?>m2 në katin <?php echo e($banesa->kati); ?></h2>
    </div>

<form method="post" action="<?php echo e(route('update', $banesa->id)); ?>">
            <?php echo method_field('PATCH'); ?> 
            <?php echo csrf_field(); ?> 
            <div class="form-group">
                <label>Statusi:</label>
                <select class="form-select" aria-label="Default select example" name="statusi">
                    <option selected value="0">E lirë</option>
                    <option value="1">E shitur</option>
                    <option value="2">E rezervuar</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary mt-2">Ruaj</button>
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\construction\resources\views/editbanesa.blade.php ENDPATH**/ ?>