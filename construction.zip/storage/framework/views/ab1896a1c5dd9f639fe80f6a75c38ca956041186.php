

<?php $__env->startSection('content'); ?>

                <h1 class="text-center mt-4 mb-5">Objektet</h1>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
  <div class="row">
  <?php $__currentLoopData = $objekts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objekt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-md-4 p-3">
  <a href="<?php echo e(route('banesat',$objekt->id)); ?>" class="text-decoration-none text-dark">
        <img src="/images/<?php echo e($objekt->image); ?>" width="100%" class="rounded">
        <h5 class="mt-2 text-center"><?php echo e($objekt->name); ?></h5>
    </a>
</div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\construction\resources\views/objektet.blade.php ENDPATH**/ ?>